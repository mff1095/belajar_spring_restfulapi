package mff.study.belajar_spring_restfullapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelajarSpringRestfullapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelajarSpringRestfullapiApplication.class, args);
	}

}
