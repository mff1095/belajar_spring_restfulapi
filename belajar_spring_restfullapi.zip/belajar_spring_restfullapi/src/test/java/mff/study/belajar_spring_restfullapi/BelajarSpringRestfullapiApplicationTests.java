package mff.study.belajar_spring_restfullapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelajarSpringRestfullapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
